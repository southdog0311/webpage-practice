package com.example.csie_contact

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper (
    context: Context,
    name: String = database,
    factory: SQLiteDatabase.CursorFactory? = null,
    version: Int = v
) : SQLiteOpenHelper(context, name, factory, version) {

    companion object {
        private const val database = "CSIE_Professors"
        private const val v = 1 //資料庫版本
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE Professors(teacher_id integer PRIMARY KEY AUTOINCREMENT, name text NOT NULL, lab text NOT NULL, phone text NOT NULL, email text)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int,
                           newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS Professors")
        onCreate(db)
    }
}